import 'package:pmovel/bd_helper.dart';
import 'package:pmovel/user.dart';
import 'package:sqflite/sqflite.dart';

class UserDao {
  salvarUser({required User user}) async {
    DBHelper dbHelper = DBHelper();
    Database db = await dbhelper.initDB();

    String sql =
        'SELECT * FROM login WHERE username =? AND email =? AND password =?;';
    var result = await db.rawQuery(sql, [username, email, password]);
    return result.isNotEmpty;
  }

  listaUsers() async {
    DBHelper dbHelper = DBHelper();
    Database db = await dbHelper.initDB();

    String sql = 'SELECT * FROM login;';
    var result = await db.rawQuery(sql);

    List<User> lista = <User>[];
    for (var json in result) {
      User user = User.fromJson(json);
      lista.add(user);
    }

    return lista;
  }
}
