import 'dart:async';

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DB {
  initBD() async {
    String databasesPath = await getDatabasesPath();
    String databaseName = join(databasesPath, 'pacotes.db');
    var db = await openDatabase(
      databaseName,
      version: 1,
      onCreate: onCreate,
    );

    print(databaseName);
    return db;
  }

  onCreate(Database db, int version) async {
    String sql =
        'CREATE TABLE login(id INTEGER PRIMARY KEY, head varchar(100), username varchar(100), email varchar(100), password varchar(100));';
    await db.execute(sql);

    sql =
        "INSERT INTO login (id, head, username, email, password) VALUES (1, 'Login', 'Amanda', 'asl13@aluno.ifal.edu.br', '4m4nd4');";
    await db.execute(sql);
    sql =
        "INSERT INTO login (id, head, username, email, password) VALUES (2, 'Login', 'Julia', 'julia@aluno.ifal.edu.br', 'ju02');";
    await db.execute(sql);

    sql =
        "INSERT INTO login (id, head, username, email, password) VALUES (3, 'Login', 'Amanda', 'asma@aluno.ifal.edu.br', 'allana78');";
    await db.execute(sql);
  }
}
